//
//  libappcast.cpp
//  appcast
//
//  Created by Adrian Gierakowski on 06/02/2015.
//  Copyright (c) 2015 Loopcast.fm. All rights reserved.
//

#include "appcast.h"

extern "C" IAppcast* GetAppcast() {
  return new Appcast;
}
